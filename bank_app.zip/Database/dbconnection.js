var pg = require('pg');
const { logger } =require( '../Util/logeer');
//or native libpq bindings

//var pg = require('pg').native



var conString = process.env.ELEPHANTSQL_URL 


exports.dbConnection=()=>{
  var client = new pg.Client(conString);

client.connect(function(err) {

  if(err) {

    return console.error('could not connect to postgres', err);

  }
  console.log('DB is connected')
  
});
return client;
}


exports.ExtractQuerry=async (con,queryString)=>{


try{
  let data= await con.query('SELECT * from players')
  logger.info(`Get the data for Querry:${queryString}}`);
  logger.info(`the Data got :${data}}`);
  return data;
}
catch(err)
{
  logger.error(`got the err while Extracting the data from Database:${err}`)
  return err;

}

}