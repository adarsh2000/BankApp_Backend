

const DB=require('../dbconnection')
exports.getPalyerById= async (data)=>{

    console.log("get the data in the repo==")
    const client=await DB.dbConnection();
    let resultdata
  resultdata= await  client.query('SELECT * from players');

              console.log("the resut ",resultdata.rows)


              client.end();
              return resultdata.rows

    // client.connect(function(err) {
    //     client.query('SELECT * from players', function(err, result) {

    //         if(err) {
        
    //           return console.error('error running query', err);
        
    //         }
        
    //         console.log(result.rows[0]);
        
    //         //output: Tue Jan 15 2013 19:12:47 GMT-600 (CST)
        
    //         client.end();
        
    //       });
    // })    



}