// const { Router } = require("express");
const playercontroller=require('../Controller/playercontroller')


module.exports=(Router)=>{
    // console.log("hello",playercontroller.getplayer)
  Router.get('/player',playercontroller.getplayer)
}